﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DrawTools
{
    public partial class FormFlux1 : Form
    {
        public FormFlux1()
        {
            InitializeComponent();
        }

        
    }
}
